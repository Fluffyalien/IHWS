#ifndef TEST_H
#define TEST_H

class Test
{
public:
	Test();
	~Test();
	int temp;
	int Current;
	int Filename;
	int setTemp;


private:
	int failed();
	
};




#endif